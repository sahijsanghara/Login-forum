package testpack;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateUser
 */
@WebServlet("/UpdateUser")
public class UpdateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int uid = (Integer) request.getSession().getAttribute("uid");
		DB_Access db = new DB_Access();
		String username = db.getUserName(uid);
		String password = db.getUserPassword(uid);
		String name = db.getName(uid);
		request.setAttribute("name", name);
		request.setAttribute("pass", password);
		request.setAttribute("usernname", username);
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/userupdate.jsp");
		rd.forward(request, response);
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int uid = (Integer) request.getSession().getAttribute("uid");
		String username = request.getParameter("username");
		String userpass = request.getParameter("userpass");
		String name = request.getParameter("personname");
		DB_Access db = new DB_Access();
		boolean res = db.updateUsers(username, name, userpass, uid);
		if(res == true) {
			response.sendRedirect("Home?msg=Account updated.");
		} else {
			response.sendRedirect("Home?msg=Error. Try again");
		}
		
	}

}