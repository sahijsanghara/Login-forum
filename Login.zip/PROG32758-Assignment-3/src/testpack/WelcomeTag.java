package testpack;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class WelcomeTag extends SimpleTagSupport {
	
	public String color = "black";
	public String size = "12";

	public void setColor(String color) {
		this.color = color;
	}
	public void setSize(String size) {
		this.size = size;
	}

	@Override
	public void doTag() throws JspException, IOException {
		super.doTag();
		JspWriter out = getJspContext().getOut();
		out.println("<h1 style=\"color:"+color+";font-size:"+size+"px;\">");
		getJspBody().invoke(null);
		out.print("</h1>");
	}
	
	
	

}
