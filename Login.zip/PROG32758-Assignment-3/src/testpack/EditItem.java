package testpack;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditItem
 */
@WebServlet("/EditItem")
public class EditItem extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if(request.getParameter("id") != null) {
			int iid = Integer.parseInt(request.getParameter("id"));
			DB_Access db = new DB_Access();
			ArrayList<Item> allItems = db.specificItem(iid);
			request.setAttribute("allItems", allItems);
			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/edititem.jsp");
			rd.forward(request, response);
		} else {
			response.sendRedirect("Home?msg=Update was not successful, please try again");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			if(request.getParameter("id") == null) {
				response.sendRedirect("Home?msg=Update was not successful, please try again");
			} else {
				int iid = Integer.parseInt(request.getParameter("id"));
				String name = request.getParameter("iname");
				String qty = request.getParameter("iqty");
				DB_Access db = new DB_Access();
				int res = db.updateItems(iid, name, qty);
				if(res == 0) {
					response.sendRedirect("Home");	
				}
				if (res == 1) {
					response.sendRedirect("EditItem?msgg= Oops, Name is incorrect, please try again");
				} 
				if (res == 2) {
					response.sendRedirect("EditItem?msgg= Oops, Number is incorrect, please try again");
				} 
			}
	}

}
