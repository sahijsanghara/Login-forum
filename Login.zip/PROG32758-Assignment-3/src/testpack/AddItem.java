package testpack;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddItem
 */
@WebServlet("/AddItem")
public class AddItem extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/additem.jsp");
		rd.forward(request, response);
		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer uid = (Integer) request.getSession().getAttribute("uid");
		String itemName = request.getParameter("iname");
		String itemqty = request.getParameter("iqty");
		DB_Access db = new DB_Access();
		int res = db.addItem(itemName, itemqty, uid);
		if(res == 0) {
			response.sendRedirect("Home");
		} else if(res == 1) {
			response.sendRedirect("AddItem?msg= Item name is incorrect, please try again");
		} else {
			response.sendRedirect("AddItem?msg= Item quantity is incorrect, please try again");
		}
	}

}
