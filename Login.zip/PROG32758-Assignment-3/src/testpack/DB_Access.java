package testpack;

import java.sql.*;
import java.util.ArrayList;

public class DB_Access {
	private String url = "jdbc:mysql://localhost:3306/test";
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String uname = "root";
	private String upass = "";
	
	private Connection c;
	private Statement st;
	private PreparedStatement pst;
	
	
	public DB_Access() {
		try {
			Class.forName(driver);
			c = DriverManager.getConnection(url, uname, upass);
			st = c.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	public int updateItems(Integer id, String name, String qty) {
		int res = 0;
		int qtyy = 0;
		if(name == null || name.trim().equals("")) return 1;
		try {
			qtyy = Integer.parseInt(qty);
		}catch(Exception e) {return 2;}
		
		String sql = "update t_items set ItemName='"+name+"', Qty='"+qtyy+"' where iid="+id+"";
		try {
			int rs = st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	public boolean updateUsers(String login,String name, String pass, int uid) {
		boolean output = true;
		if(login == null || login.trim().equals("")) {
			return false;
		}
		if(name == null || name.trim().equals("")) {
			return false;
		}
		if(pass == null || pass.trim().equals("")) {
			return false;
		}
		try {
			String sql = "update t_users set LoginName='"+login+"', Name='"+name+"', LoginPass='"+pass+"' where uid="+uid+"";
			int rs = st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
			output=false;
		}
		return output;
	}
	public boolean DeleteItem(int id) {
		boolean output = true;
		String sql = "delete from t_items where iid="+id;
		try {
			int rs = st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
			output=false;
		}
		return output;
	}
	public int validateLogin(String un, String up) {
		int uid = -1; 
		
		String sql = "select uid from t_users where LoginName = ? and LoginPass = ?";
		try {
			pst = c.prepareStatement(sql);
			pst.setString(1, un);
			pst.setString(2, up);
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				uid = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return uid;
	}
	public String getUserPassword(int uid) {
		String sql = "select LoginPass from t_users where uid = " + uid;
		String upass = "";
		try {
			ResultSet rs = st.executeQuery(sql);
			if(rs.next()) upass = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return upass;
	}
	
	public String getUserName(int uid) {
		String sql = "select LoginName from t_users where uid = " + uid;
		String uname = "";
		try {
			ResultSet rs = st.executeQuery(sql);
			if(rs.next()) uname = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return uname;
	}
	public String getName(int uid) {
		String sql = "select Name from t_users where uid = " + uid;
		String uname = "";
		try {
			ResultSet rs = st.executeQuery(sql);
			if(rs.next()) uname = rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return uname;
	}
	public ArrayList<Item> specificItem(int uid) {
		ArrayList<Item> all = new ArrayList<Item>();
		
		String sql = "select iid, ItemName, qty from t_items where iid = " + uid;
		
		try {
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				Item i = new Item(rs.getInt(1), rs.getString(2), rs.getInt(3));
				all.add(i);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		return all;
	}
	public ArrayList<Item> getAllUserItems(int uid) {
		ArrayList<Item> all = new ArrayList<Item>();
		
		String sql = "select iid, Itemname, Qty from t_items where uid = " + uid;
		
		try {
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				Item i = new Item(rs.getInt(1), rs.getString(2), rs.getInt(3));
				all.add(i);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		return all;
	}
	
	public int createUserAccount(User u) {

		int status = 0;
		
		if(u.getLoginName().trim().equals("") || 
				u.getName().trim().equals("") || 
				u.getLoginPass1().trim().equals("") ||
				u.getLoginPass2().trim().equals("")) return 3;
		if(u.getLoginName().trim().length() > 20 || 
				u.getName().trim().length() > 20 || 
				u.getLoginPass1().trim().length()> 20 ||
				u.getLoginPass2().trim().length()>20) return 1;
		
		if(!u.getLoginPass1().trim().equals(u.getLoginPass2().trim())) return 4;
		
		String sql = "insert into t_users (LoginName, Name, LoginPass) values (?, ?, ?)";
		
		try {
			pst = c.prepareStatement(sql);
			pst.setString(1, u.getLoginName());
			pst.setString(2, u.getName());
			pst.setString(3, u.getLoginPass1());
			pst.executeUpdate();
		} catch (SQLException e) {
			status = 2;
			e.printStackTrace();
		}

		return status;
	}
	
	
	public int addItem(String iname, String iqty, Integer uid) {
		int res = 0;
		int qty = 0;
		if(iname == null || iname.trim().equals("")) return 1;
		try {
			qty = Integer.parseInt(iqty);
		}catch(Exception e) {return 2;}
		
		String sql = "insert into t_items (ItemName, Qty, uid) values (?, ?, ?)";
		try {
			pst = c.prepareStatement(sql);
			pst.setString(1, iname);
			pst.setInt(2, qty);
			pst.setInt(3, uid);
			pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
}












